# -*- coding: utf-8 -*-

token = 'here make token'
